package com.connectmymatch.task;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.SubjectViewHolder>{

    private Context context;
    private List<Subject>subjectList;
    private ArrayList<String> progress;

    public RecyclerViewAdapter(List<Subject> subjectList, ArrayList<String> progress ,Context context) {
        this.subjectList = subjectList;
        this.context = context;
        this.progress = progress;
    }

    @NonNull
    @Override
    public SubjectViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.subject_recyclerview_item,parent,false);
        SubjectViewHolder holder = new SubjectViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull SubjectViewHolder holder, int position) {
        Subject subject =subjectList.get(position);
        holder.subjectIcon.setImageDrawable(context.getResources().getDrawable(subject.getSubjectIconId()));
        holder.subjectTitle.setText(subject.getSubjectTitle());
        holder.subjectProgressText.setText(progress.get(position));

        float progressToFloat = Float.parseFloat(progress.get(position).substring(0,progress.get(position).indexOf("%")));
        int progressToInt = (int) progressToFloat;

        holder.progressBar.setProgress(progressToInt);

    }

    @Override
    public int getItemCount() {
        return subjectList.size();
    }

    class SubjectViewHolder extends RecyclerView.ViewHolder{

        ProgressBar progressBar;
        ImageView subjectIcon;
        TextView subjectTitle, subjectProgressText;

        public SubjectViewHolder(@NonNull View itemView) {
            super(itemView);
            subjectIcon = itemView.findViewById(R.id.subjectIcon);
            subjectTitle = itemView.findViewById(R.id.subjectTitle);
            progressBar = itemView.findViewById(R.id.subjectProgress);
            subjectProgressText = itemView.findViewById(R.id.subjectProgressText);
        }
    }
}
