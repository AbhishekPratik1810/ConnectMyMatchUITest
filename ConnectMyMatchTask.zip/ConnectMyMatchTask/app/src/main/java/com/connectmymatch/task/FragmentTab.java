package com.connectmymatch.task;


import android.os.Bundle;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentTab extends Fragment {

    private String title;
    private TextView textView;
    public FragmentTab(String title) {
        this.title = title;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fragment_tab, container, false);
        instantiateViews(view);
        return view;
    }

    public void instantiateViews(View view){
        textView = view.findViewById(R.id.titleFragment);
        Log.i("title",title);
        textView.setText(title);
        Log.i("setText",textView.getText().toString());
    }

}
