package com.connectmymatch.task;

public class Subject {
    private int subjectIconId;
    private String subjectTitle;

    public Subject(int subjectIconId, String subjectTitle) {
        this.subjectIconId = subjectIconId;
        this.subjectTitle = subjectTitle;
    }

    public int getSubjectIconId() {
        return subjectIconId;
    }

    public String getSubjectTitle() {
        return subjectTitle;
    }
}
