package com.connectmymatch.task;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {

    private RecyclerView subjectRecyclerView;
    private RecyclerViewAdapter subjectRecyclerViewAdapter;
    private ArrayList<Subject> subjects;
    private ArrayList<String> progress;
    private Toolbar toolbar;
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;
    private NavigationView navigationView;

    private ImageView wallet, trophy;
    private Button upgradeNow;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        instantiateViews(view);
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        navigationView.setNavigationItemSelectedListener(this);

        wallet.setOnClickListener(this);
        trophy.setOnClickListener(this);
        upgradeNow.setOnClickListener(this);

        return view;
    }

    private void instantiateViews(View view) {
        toolbar = view.findViewById(R.id.topToolbar);

        drawerLayout = view.findViewById(R.id.menu_drawer_layout);
        toggle = new ActionBarDrawerToggle(getActivity(), drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        subjects = new ArrayList<>();
        subjects.add(new Subject(R.drawable.bulb_icon_tranparent, "Mental Ability"));
        subjects.add(new Subject(R.drawable.magnet_icon_transparent, "Physics"));
        subjects.add(new Subject(R.drawable.bottle_icon_transparent, "Chemistry"));
        subjects.add(new Subject(R.drawable.scale, "Mathematics"));

        progress = new ArrayList<>();
        progress.add("0%");
        progress.add("45.7%");
        progress.add("78.2%");
        progress.add("50%");

        subjectRecyclerView = view.findViewById(R.id.subjectRecyclerView);
        subjectRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        subjectRecyclerViewAdapter = new RecyclerViewAdapter(subjects, progress,getActivity());
        subjectRecyclerView.setAdapter(subjectRecyclerViewAdapter);

        navigationView = view.findViewById(R.id.navigationDrawer);

        wallet = view.findViewById(R.id.wallet);
        trophy = view.findViewById(R.id.trophy);
        upgradeNow = view.findViewById(R.id.upgradeNow);

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.nav_home:
                break;
            case R.id.nav_tab2:
                Toast.makeText(getActivity(),"Tab2 Selected",Toast.LENGTH_LONG).show();
                break;
            case R.id.nav_tab3:
                Toast.makeText(getActivity(),"Tab3 Selected",Toast.LENGTH_LONG).show();
                break;
            case R.id.nav_tab4:
                Toast.makeText(getActivity(),"Tab4 Selected",Toast.LENGTH_LONG).show();
                break;
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.wallet:
                Toast.makeText(getActivity(),"Wallet Clicked",Toast.LENGTH_LONG).show();
                break;
            case R.id.trophy:
                Toast.makeText(getActivity(),"Achievements Clicked",Toast.LENGTH_LONG).show();
                break;
            case R.id.upgradeNow:
                Toast.makeText(getActivity(),"Upgrade Now Clicked",Toast.LENGTH_LONG).show();
                break;
        }
    }

    @Override
    public void onResume(){
        super.onResume();
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }
}
